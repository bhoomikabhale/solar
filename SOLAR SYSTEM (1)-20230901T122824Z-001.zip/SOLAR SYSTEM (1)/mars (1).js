function next(){
    window.location="jupiter.html";
    console.log("start journey of jupiter");
}