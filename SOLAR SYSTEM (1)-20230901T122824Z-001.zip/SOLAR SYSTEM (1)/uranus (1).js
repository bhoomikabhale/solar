function next(){
    window.location="neptune.html";
    console.log("start journey of neptune");
}