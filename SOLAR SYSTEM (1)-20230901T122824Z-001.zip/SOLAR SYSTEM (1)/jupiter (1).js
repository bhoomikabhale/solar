function next(){
    window.location="saturn.html";
    console.log("start journey of saturn");
}