function next(){
    window.location="earth.html";
    console.log("start journey of earth");
}