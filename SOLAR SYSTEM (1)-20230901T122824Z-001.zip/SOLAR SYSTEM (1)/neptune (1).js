function home(){
    window.location="ss.html";
    console.log("JOURNEY ENDED");
}