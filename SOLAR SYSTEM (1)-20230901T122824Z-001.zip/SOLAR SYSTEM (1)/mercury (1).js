function next(){
    window.location="venus.html";
    console.log("start journey of venus");
}