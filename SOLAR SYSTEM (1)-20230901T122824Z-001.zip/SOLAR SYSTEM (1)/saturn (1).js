function next(){
    window.location="uranus.html";
    console.log("start journey of uranus");
}