function start(){
    window.location="mercury.html";
    console.log("start journey of mercury");
}