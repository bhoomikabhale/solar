function next(){
    window.location="mars.html";
    console.log("start journey of mars");
}